﻿Public Class AboutForm


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Process.Start("http://kairoware.rf.gd")
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://icons8.com.br/icon/set/copy%20paste/windows")
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub
End Class