﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.tab = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.PictureBoxColorSelected = New System.Windows.Forms.PictureBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ButtonBold = New System.Windows.Forms.Button()
        Me.ButtonItalic = New System.Windows.Forms.Button()
        Me.ButtonUnderlined = New System.Windows.Forms.Button()
        Me.ButtonStrikeout = New System.Windows.Forms.Button()
        Me.ButtonLeft = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.LabelTextSize = New System.Windows.Forms.Label()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.ButtonCenter = New System.Windows.Forms.Button()
        Me.ButtonRight = New System.Windows.Forms.Button()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.LabelWordCount = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RichTextBoxPrintCtrl1 = New ProBaseAdvancedTextBox.ProBaseAdvancedTextBox.RichTextBoxPrintCtrl()
        Me.Spelling1 = New NetSpell.SpellChecker.Spelling(Me.components)
        Me.WordDictionary1 = New NetSpell.SpellChecker.Dictionary.WordDictionary(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PanelFileMenu = New System.Windows.Forms.Panel()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.LabelStatus = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.Panel1.SuspendLayout()
        Me.tab.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBoxColorSelected, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.PanelFileMenu.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.tab)
        Me.Panel1.Controls.Add(Me.Button9)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1329, 95)
        Me.Panel1.TabIndex = 0
        '
        'tab
        '
        Me.tab.Controls.Add(Me.TabPage2)
        Me.tab.Controls.Add(Me.TabPage1)
        Me.tab.Controls.Add(Me.TabPage3)
        Me.tab.Dock = System.Windows.Forms.DockStyle.Right
        Me.tab.Location = New System.Drawing.Point(179, 0)
        Me.tab.Name = "tab"
        Me.tab.SelectedIndex = 0
        Me.tab.Size = New System.Drawing.Size(1150, 95)
        Me.tab.TabIndex = 4
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.PictureBoxColorSelected)
        Me.TabPage2.Controls.Add(Me.Button10)
        Me.TabPage2.Controls.Add(Me.Panel3)
        Me.TabPage2.Controls.Add(Me.ButtonBold)
        Me.TabPage2.Controls.Add(Me.ButtonItalic)
        Me.TabPage2.Controls.Add(Me.ButtonUnderlined)
        Me.TabPage2.Controls.Add(Me.ButtonStrikeout)
        Me.TabPage2.Controls.Add(Me.ButtonLeft)
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Controls.Add(Me.ButtonCenter)
        Me.TabPage2.Controls.Add(Me.ButtonRight)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1142, 69)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Fonte"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'PictureBoxColorSelected
        '
        Me.PictureBoxColorSelected.BackColor = System.Drawing.Color.Black
        Me.PictureBoxColorSelected.Location = New System.Drawing.Point(6, 36)
        Me.PictureBoxColorSelected.Name = "PictureBoxColorSelected"
        Me.PictureBoxColorSelected.Size = New System.Drawing.Size(76, 2)
        Me.PictureBoxColorSelected.TabIndex = 6
        Me.PictureBoxColorSelected.TabStop = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button10.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button10.FlatAppearance.BorderSize = 0
        Me.Button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Button10.Location = New System.Drawing.Point(6, 8)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(76, 22)
        Me.Button10.TabIndex = 5
        Me.Button10.Text = "A"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel3.Controls.Add(Me.ComboBox1)
        Me.Panel3.Location = New System.Drawing.Point(91, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(147, 35)
        Me.Panel3.TabIndex = 14
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.Color.White
        Me.ComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox1.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.ComboBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(3, 6)
        Me.ComboBox1.MinimumSize = New System.Drawing.Size(139, 0)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(139, 24)
        Me.ComboBox1.TabIndex = 13
        '
        'ButtonBold
        '
        Me.ButtonBold.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonBold.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonBold.FlatAppearance.BorderSize = 0
        Me.ButtonBold.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonBold.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonBold.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonBold.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Bold)
        Me.ButtonBold.ForeColor = System.Drawing.Color.DimGray
        Me.ButtonBold.Location = New System.Drawing.Point(352, 4)
        Me.ButtonBold.Name = "ButtonBold"
        Me.ButtonBold.Size = New System.Drawing.Size(30, 30)
        Me.ButtonBold.TabIndex = 6
        Me.ButtonBold.Text = "B"
        Me.ButtonBold.UseVisualStyleBackColor = False
        '
        'ButtonItalic
        '
        Me.ButtonItalic.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonItalic.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonItalic.FlatAppearance.BorderSize = 0
        Me.ButtonItalic.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonItalic.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonItalic.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonItalic.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Italic)
        Me.ButtonItalic.ForeColor = System.Drawing.Color.DimGray
        Me.ButtonItalic.Location = New System.Drawing.Point(316, 37)
        Me.ButtonItalic.Name = "ButtonItalic"
        Me.ButtonItalic.Size = New System.Drawing.Size(30, 30)
        Me.ButtonItalic.TabIndex = 7
        Me.ButtonItalic.Text = "I"
        Me.ButtonItalic.UseVisualStyleBackColor = False
        '
        'ButtonUnderlined
        '
        Me.ButtonUnderlined.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonUnderlined.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonUnderlined.FlatAppearance.BorderSize = 0
        Me.ButtonUnderlined.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonUnderlined.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonUnderlined.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonUnderlined.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Underline)
        Me.ButtonUnderlined.ForeColor = System.Drawing.Color.DimGray
        Me.ButtonUnderlined.Location = New System.Drawing.Point(280, 37)
        Me.ButtonUnderlined.Name = "ButtonUnderlined"
        Me.ButtonUnderlined.Size = New System.Drawing.Size(30, 30)
        Me.ButtonUnderlined.TabIndex = 8
        Me.ButtonUnderlined.Text = "U"
        Me.ButtonUnderlined.UseVisualStyleBackColor = False
        '
        'ButtonStrikeout
        '
        Me.ButtonStrikeout.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonStrikeout.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonStrikeout.FlatAppearance.BorderSize = 0
        Me.ButtonStrikeout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonStrikeout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonStrikeout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonStrikeout.Font = New System.Drawing.Font("Verdana", 6.0!, System.Drawing.FontStyle.Strikeout)
        Me.ButtonStrikeout.ForeColor = System.Drawing.Color.DimGray
        Me.ButtonStrikeout.Location = New System.Drawing.Point(244, 37)
        Me.ButtonStrikeout.Name = "ButtonStrikeout"
        Me.ButtonStrikeout.Size = New System.Drawing.Size(30, 28)
        Me.ButtonStrikeout.TabIndex = 9
        Me.ButtonStrikeout.Text = "abc"
        Me.ButtonStrikeout.UseVisualStyleBackColor = False
        '
        'ButtonLeft
        '
        Me.ButtonLeft.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonLeft.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonLeft.FlatAppearance.BorderSize = 0
        Me.ButtonLeft.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonLeft.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonLeft.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.ButtonLeft.ForeColor = System.Drawing.Color.DimGray
        Me.ButtonLeft.Image = Global.KairoWare_writer.My.Resources.Resources.icons8_alinhar_à_direita_32
        Me.ButtonLeft.Location = New System.Drawing.Point(244, 6)
        Me.ButtonLeft.Name = "ButtonLeft"
        Me.ButtonLeft.Size = New System.Drawing.Size(30, 28)
        Me.ButtonLeft.TabIndex = 10
        Me.ButtonLeft.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ButtonLeft.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel4.Controls.Add(Me.LabelTextSize)
        Me.Panel4.Controls.Add(Me.Button18)
        Me.Panel4.Location = New System.Drawing.Point(388, 4)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(51, 62)
        Me.Panel4.TabIndex = 15
        '
        'LabelTextSize
        '
        Me.LabelTextSize.BackColor = System.Drawing.Color.White
        Me.LabelTextSize.Font = New System.Drawing.Font("Verdana", 12.0!)
        Me.LabelTextSize.Location = New System.Drawing.Point(3, 4)
        Me.LabelTextSize.Name = "LabelTextSize"
        Me.LabelTextSize.Size = New System.Drawing.Size(45, 35)
        Me.LabelTextSize.TabIndex = 13
        Me.LabelTextSize.Text = "10"
        Me.LabelTextSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button18.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button18.FlatAppearance.BorderSize = 0
        Me.Button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button18.Font = New System.Drawing.Font("Verdana", 5.0!)
        Me.Button18.ForeColor = System.Drawing.Color.DimGray
        Me.Button18.Location = New System.Drawing.Point(3, 39)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(45, 20)
        Me.Button18.TabIndex = 12
        Me.Button18.Text = "Pixels"
        Me.Button18.UseVisualStyleBackColor = False
        '
        'ButtonCenter
        '
        Me.ButtonCenter.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonCenter.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonCenter.FlatAppearance.BorderSize = 0
        Me.ButtonCenter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonCenter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonCenter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonCenter.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.ButtonCenter.ForeColor = System.Drawing.Color.DimGray
        Me.ButtonCenter.Image = Global.KairoWare_writer.My.Resources.Resources.icons8_alinhar_justificado_32
        Me.ButtonCenter.Location = New System.Drawing.Point(280, 6)
        Me.ButtonCenter.Name = "ButtonCenter"
        Me.ButtonCenter.Size = New System.Drawing.Size(30, 28)
        Me.ButtonCenter.TabIndex = 11
        Me.ButtonCenter.UseVisualStyleBackColor = False
        '
        'ButtonRight
        '
        Me.ButtonRight.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonRight.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonRight.FlatAppearance.BorderSize = 0
        Me.ButtonRight.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonRight.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.ButtonRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonRight.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.ButtonRight.ForeColor = System.Drawing.Color.DimGray
        Me.ButtonRight.Image = Global.KairoWare_writer.My.Resources.Resources.icons8_alinhar_à_esquerda_32
        Me.ButtonRight.Location = New System.Drawing.Point(316, 4)
        Me.ButtonRight.Name = "ButtonRight"
        Me.ButtonRight.Size = New System.Drawing.Size(30, 30)
        Me.ButtonRight.TabIndex = 12
        Me.ButtonRight.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ButtonRight.UseVisualStyleBackColor = False
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button21)
        Me.TabPage1.Controls.Add(Me.Button22)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1142, 69)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Inserir"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button21.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button21.FlatAppearance.BorderSize = 0
        Me.Button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button21.ForeColor = System.Drawing.Color.DimGray
        Me.Button21.Location = New System.Drawing.Point(102, 6)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(99, 54)
        Me.Button21.TabIndex = 18
        Me.Button21.Text = "Imagen"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button22.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button22.FlatAppearance.BorderSize = 0
        Me.Button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button22.ForeColor = System.Drawing.Color.DimGray
        Me.Button22.Location = New System.Drawing.Point(6, 6)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(90, 54)
        Me.Button22.TabIndex = 19
        Me.Button22.Text = "Data e hora"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Button23)
        Me.TabPage3.Controls.Add(Me.Button19)
        Me.TabPage3.Controls.Add(Me.Button20)
        Me.TabPage3.Controls.Add(Me.Button26)
        Me.TabPage3.Controls.Add(Me.Button25)
        Me.TabPage3.Controls.Add(Me.Button24)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1142, 69)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Outros"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button23.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button23.FlatAppearance.BorderSize = 0
        Me.Button23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button23.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button23.ForeColor = System.Drawing.Color.DimGray
        Me.Button23.Location = New System.Drawing.Point(409, 7)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(91, 57)
        Me.Button23.TabIndex = 20
        Me.Button23.Text = "Imprimir"
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button19.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button19.FlatAppearance.BorderSize = 0
        Me.Button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button19.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button19.ForeColor = System.Drawing.Color.DimGray
        Me.Button19.Location = New System.Drawing.Point(6, 6)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(77, 57)
        Me.Button19.TabIndex = 16
        Me.Button19.Text = "Sobrescrito"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button20.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button20.FlatAppearance.BorderSize = 0
        Me.Button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button20.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button20.ForeColor = System.Drawing.Color.DimGray
        Me.Button20.Location = New System.Drawing.Point(89, 4)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(77, 60)
        Me.Button20.TabIndex = 17
        Me.Button20.Text = "Subscrito"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button26.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button26.FlatAppearance.BorderSize = 0
        Me.Button26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button26.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button26.ForeColor = System.Drawing.Color.DimGray
        Me.Button26.Location = New System.Drawing.Point(265, 5)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(50, 58)
        Me.Button26.TabIndex = 23
        Me.Button26.Text = "Narrar"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button25.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button25.FlatAppearance.BorderSize = 0
        Me.Button25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button25.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button25.ForeColor = System.Drawing.Color.DimGray
        Me.Button25.Location = New System.Drawing.Point(172, 6)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(87, 57)
        Me.Button25.TabIndex = 22
        Me.Button25.Text = "Procurar ..."
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button24.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button24.FlatAppearance.BorderSize = 0
        Me.Button24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button24.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button24.ForeColor = System.Drawing.Color.DimGray
        Me.Button24.Location = New System.Drawing.Point(321, 5)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(82, 60)
        Me.Button24.TabIndex = 21
        Me.Button24.Text = "Verificação ortográfica"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.Transparent
        Me.Button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button9.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button9.ForeColor = System.Drawing.Color.DimGray
        Me.Button9.Image = Global.KairoWare_writer.My.Resources.Resources.icons8_copiar_32
        Me.Button9.Location = New System.Drawing.Point(24, 31)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(33, 30)
        Me.Button9.TabIndex = 4
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.Transparent
        Me.Button8.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button8.ForeColor = System.Drawing.Color.DimGray
        Me.Button8.Image = Global.KairoWare_writer.My.Resources.Resources.icons8_recortar_32
        Me.Button8.Location = New System.Drawing.Point(132, 31)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(33, 28)
        Me.Button8.TabIndex = 3
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Transparent
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button7.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button7.ForeColor = System.Drawing.Color.DimGray
        Me.Button7.Image = Global.KairoWare_writer.My.Resources.Resources.icons8_colar_32
        Me.Button7.Location = New System.Drawing.Point(63, 25)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(58, 41)
        Me.Button7.TabIndex = 2
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.LabelWordCount)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1329, 24)
        Me.Panel2.TabIndex = 1
        '
        'LabelWordCount
        '
        Me.LabelWordCount.Dock = System.Windows.Forms.DockStyle.Right
        Me.LabelWordCount.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.LabelWordCount.ForeColor = System.Drawing.Color.Gray
        Me.LabelWordCount.Location = New System.Drawing.Point(1023, 0)
        Me.LabelWordCount.Name = "LabelWordCount"
        Me.LabelWordCount.Size = New System.Drawing.Size(306, 24)
        Me.LabelWordCount.TabIndex = 3
        Me.LabelWordCount.Text = "Word Count : "
        Me.LabelWordCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Gainsboro
        Me.Button3.BackgroundImage = Global.KairoWare_writer.My.Resources.Resources.icons8_seta_para_a_frente_32
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button3.ForeColor = System.Drawing.Color.DimGray
        Me.Button3.Location = New System.Drawing.Point(121, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(44, 24)
        Me.Button3.TabIndex = 2
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Gainsboro
        Me.Button2.BackgroundImage = Global.KairoWare_writer.My.Resources.Resources.icons8_seta_para_a_frente_32___Copia
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Verdana", 7.0!)
        Me.Button2.ForeColor = System.Drawing.Color.DimGray
        Me.Button2.Location = New System.Drawing.Point(74, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(47, 24)
        Me.Button2.TabIndex = 1
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(0, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(74, 24)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "&Arquivo"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'RichTextBoxPrintCtrl1
        '
        Me.RichTextBoxPrintCtrl1.AutoWordSelection = True
        Me.RichTextBoxPrintCtrl1.BackColor = System.Drawing.Color.White
        Me.RichTextBoxPrintCtrl1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBoxPrintCtrl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBoxPrintCtrl1.EnableAutoDragDrop = True
        Me.RichTextBoxPrintCtrl1.Font = New System.Drawing.Font("Arial", 10.0!)
        Me.RichTextBoxPrintCtrl1.ForeColor = System.Drawing.Color.Black
        Me.RichTextBoxPrintCtrl1.HideSelection = False
        Me.RichTextBoxPrintCtrl1.Location = New System.Drawing.Point(258, 0)
        Me.RichTextBoxPrintCtrl1.Name = "RichTextBoxPrintCtrl1"
        Me.RichTextBoxPrintCtrl1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBoxPrintCtrl1.Size = New System.Drawing.Size(1042, 488)
        Me.RichTextBoxPrintCtrl1.TabIndex = 2
        Me.RichTextBoxPrintCtrl1.Text = ""
        '
        'Spelling1
        '
        Me.Spelling1.Dictionary = Me.WordDictionary1
        '
        'WordDictionary1
        '
        Me.WordDictionary1.DictionaryFile = "portugues.dic"
        Me.WordDictionary1.UserFile = ""
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'FontDialog1
        '
        Me.FontDialog1.AllowVerticalFonts = False
        Me.FontDialog1.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.FontDialog1.FontMustExist = True
        Me.FontDialog1.MaxSize = 200
        Me.FontDialog1.ShowEffects = False
        '
        'ColorDialog1
        '
        Me.ColorDialog1.FullOpen = True
        '
        'PrintDocument1
        '
        Me.PrintDocument1.DocumentName = "Wiriter  Document"
        '
        'PanelFileMenu
        '
        Me.PanelFileMenu.AutoScroll = True
        Me.PanelFileMenu.Controls.Add(Me.Button12)
        Me.PanelFileMenu.Controls.Add(Me.Button30)
        Me.PanelFileMenu.Controls.Add(Me.Button11)
        Me.PanelFileMenu.Controls.Add(Me.Button29)
        Me.PanelFileMenu.Controls.Add(Me.Button6)
        Me.PanelFileMenu.Controls.Add(Me.Button5)
        Me.PanelFileMenu.Controls.Add(Me.Button4)
        Me.PanelFileMenu.Controls.Add(Me.Button27)
        Me.PanelFileMenu.Controls.Add(Me.Label2)
        Me.PanelFileMenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelFileMenu.Location = New System.Drawing.Point(0, 0)
        Me.PanelFileMenu.Name = "PanelFileMenu"
        Me.PanelFileMenu.Size = New System.Drawing.Size(258, 488)
        Me.PanelFileMenu.TabIndex = 3
        Me.PanelFileMenu.Visible = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button12.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button12.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button12.FlatAppearance.BorderSize = 0
        Me.Button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button12.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button12.ForeColor = System.Drawing.Color.DimGray
        Me.Button12.Location = New System.Drawing.Point(0, 341)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(258, 40)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "    Supporte"
        Me.Button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button30.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button30.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button30.FlatAppearance.BorderSize = 0
        Me.Button30.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button30.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button30.ForeColor = System.Drawing.Color.DimGray
        Me.Button30.Location = New System.Drawing.Point(0, 301)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(258, 40)
        Me.Button30.TabIndex = 9
        Me.Button30.Text = "    Sair"
        Me.Button30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button11.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button11.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button11.FlatAppearance.BorderSize = 0
        Me.Button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button11.ForeColor = System.Drawing.Color.DimGray
        Me.Button11.Location = New System.Drawing.Point(0, 261)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(258, 40)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "    Sobre"
        Me.Button11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button29.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button29.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button29.FlatAppearance.BorderSize = 0
        Me.Button29.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button29.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button29.ForeColor = System.Drawing.Color.DimGray
        Me.Button29.Location = New System.Drawing.Point(0, 221)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(258, 40)
        Me.Button29.TabIndex = 8
        Me.Button29.Text = "    Imprimir"
        Me.Button29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button6.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button6.ForeColor = System.Drawing.Color.DimGray
        Me.Button6.Location = New System.Drawing.Point(0, 181)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(258, 40)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "    Abrir"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button5.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button5.ForeColor = System.Drawing.Color.DimGray
        Me.Button5.Location = New System.Drawing.Point(0, 141)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(258, 40)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "    Savar Como"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button4.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button4.ForeColor = System.Drawing.Color.DimGray
        Me.Button4.Location = New System.Drawing.Point(0, 101)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(258, 40)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "    Savar"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button27.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button27.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.Button27.FlatAppearance.BorderSize = 0
        Me.Button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gainsboro
        Me.Button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro
        Me.Button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button27.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Button27.ForeColor = System.Drawing.Color.DimGray
        Me.Button27.Location = New System.Drawing.Point(0, 61)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(258, 40)
        Me.Button27.TabIndex = 6
        Me.Button27.Text = "    Novo Arquivo"
        Me.Button27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button27.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Verdana", 20.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(258, 61)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "  &Arquivo"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel5.Controls.Add(Me.RichTextBoxPrintCtrl1)
        Me.Panel5.Controls.Add(Me.PanelFileMenu)
        Me.Panel5.Location = New System.Drawing.Point(16, 134)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1300, 488)
        Me.Panel5.TabIndex = 4
        '
        'LabelStatus
        '
        Me.LabelStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LabelStatus.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LabelStatus.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Bold)
        Me.LabelStatus.ForeColor = System.Drawing.Color.DimGray
        Me.LabelStatus.Location = New System.Drawing.Point(16, 622)
        Me.LabelStatus.Name = "LabelStatus"
        Me.LabelStatus.Size = New System.Drawing.Size(1300, 24)
        Me.LabelStatus.TabIndex = 5
        Me.LabelStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BackgroundImage = Global.KairoWare_writer.My.Resources.Resources.Sem_Título_1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1329, 655)
        Me.Controls.Add(Me.LabelStatus)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel5)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 8.25!)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(822, 232)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Writer"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.tab.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        CType(Me.PictureBoxColorSelected, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.PanelFileMenu.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents LabelTextSize As System.Windows.Forms.Label
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ButtonRight As System.Windows.Forms.Button
    Friend WithEvents ButtonCenter As System.Windows.Forms.Button
    Friend WithEvents ButtonLeft As System.Windows.Forms.Button
    Friend WithEvents ButtonStrikeout As System.Windows.Forms.Button
    Friend WithEvents ButtonUnderlined As System.Windows.Forms.Button
    Friend WithEvents ButtonItalic As System.Windows.Forms.Button
    Friend WithEvents ButtonBold As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents RichTextBoxPrintCtrl1 As ProBaseAdvancedTextBox.ProBaseAdvancedTextBox.RichTextBoxPrintCtrl
    Friend WithEvents Spelling1 As NetSpell.SpellChecker.Spelling
    Friend WithEvents WordDictionary1 As NetSpell.SpellChecker.Dictionary.WordDictionary
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents LabelWordCount As System.Windows.Forms.Label
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Public WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PanelFileMenu As System.Windows.Forms.Panel
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents LabelStatus As System.Windows.Forms.Label
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents PictureBoxColorSelected As System.Windows.Forms.PictureBox
    Friend WithEvents tab As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Button12 As Button
End Class
